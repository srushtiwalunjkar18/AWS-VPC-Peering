# AWS VPC Peering Practical

**Author**: Srushti Santosh Walunjkar
**Project**: Project 01: AWS VPC Peering
**Course**: AWS Architect Associate (EWB Courses)
**Region**: Asia Pacific (Mumbai) / ap-south-1

## Overview
This repository contains the documentation and evidence for building, testing, and cleaning up a VPC peering connection between VPC A (10.10.0.0/16) and VPC B (10.20.0.0/16). The architecture utilizes three EC2 instances, custom route tables, security groups, and a public bastion host. All operations and traffic are restricted to private IPs using an SSH ProxyJump configuration.

## Architecture
- **VPC A (ewb-vpc-a)**: `10.10.0.0/16`
  - Public Subnet (`ewb-a-public`): `10.10.1.0/24`
  - Private Subnet (`ewb-a-private`): `10.10.2.0/24`
- **VPC B (ewb-vpc-b)**: `10.20.0.0/16`
  - Private Subnet (`ewb-b-private`): `10.20.1.0/24`
- **Peering Connection**: `pcx-043231649a33e5164` (Directly links VPC A to VPC B)

### Workloads
1. **Bastion Host (ewb-bastion)**: `10.10.1.10` (Publicly accessible via strict IP whitelist for admin access)
2. **App-A (ewb-app-a)**: `10.10.2.10` (Private)
3. **App-B (ewb-app-b)**: `10.20.1.10` (Private)

## Security Groups
- **ewb-sg-bastion (VPC A)**: Allows SSH (TCP 22) strictly from authorized ISP range to access the bastion.
- **ewb-sg-app-a (VPC A)**: Allows SSH from the Bastion (`10.10.1.10/32`) and Custom ICMP Echo Request from App-B (`10.20.1.10/32`).
- **ewb-sg-app-b (VPC B)**: Allows SSH from the Bastion (`10.10.1.10/32`) and Custom ICMP Echo Request from App-A (`10.10.2.10/32`).

## Key Network Configurations
- **Forward Path (App-A to App-B)**: Traffic routes over `10.20.0.0/16` via peering connection. Target security group allows ICMP.
- **Return Path**: Route table in VPC B has a return path mapped (`10.10.0.0/16` to the peering connection) to ensure replies do not get dropped.

## Key Learnings
1. Two VPCs are isolated by default; a peering connection establishes the physical link.
2. Peering alone is not enough; explicit route tables and stateful security group rules on both sides are mandatory for traffic flow.
3. Subnets without explicit route table associations silently use the main route table, which can lead to traffic blackholes.
4. SSH ProxyJump allows managing private instances securely without copying private keys or exposing them publicly.
